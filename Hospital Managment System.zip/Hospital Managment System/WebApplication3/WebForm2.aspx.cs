﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            string username;
            string password;
            username = Convert.ToString(TextBox1.Text);
            password = Convert.ToString(TextBox2.Text);
            if ((TextBox2.Text != string.Empty) && (username == "shayan") && (password == "shayan123"))
            {
                Response.Redirect("WebForm3.aspx");
            }
            else if ((TextBox2.Text != string.Empty) && (username == "nouman") && (password == "nouman123"))
            {
                Response.Redirect("WebForm3.aspx");
            }
            else if ((TextBox2.Text != string.Empty) && (username == "huzaifa") && (password == "huzaifa123"))
            {
                Response.Redirect("WebForm3.aspx");
            }
            else
            {
                Response.Redirect("WebForm5.aspx");
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm6.aspx");
        }
        
        
      
        }

       

        }

     
    
