﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }



       
        protected void Button5_Click(object sender, EventArgs e)
        {
              string username;
            string password;
            username = Convert.ToString(DropDownList1.Text);
            password = Convert.ToString(TextBox3.Text);
            if ((TextBox3.Text != string.Empty) && (username == "Dr Huzaifa") && (password == "huzaifa123"))
            {
                Response.Redirect("WebForm10.aspx");
            }
            else if ((TextBox3.Text != string.Empty) && (username == "Dr Affan") && (password == "affan123"))
            {
                Response.Redirect("WebForm10.aspx");
            }
            else if ((TextBox3.Text != string.Empty) && (username == "Dr Osman") && (password == "osman123"))
            {
                Response.Redirect("WebForm10.aspx");
            }
            else
            {
                Response.Redirect("WebForm9.aspx");
            }
        }

        }
    }



        
  
