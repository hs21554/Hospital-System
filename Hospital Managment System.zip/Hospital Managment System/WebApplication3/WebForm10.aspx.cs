﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication3
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=LAPTOP-9AUKFI0Q\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string query = "insert into PD values('" + DropDownList4.Text + "','" + DropDownList3.Text + "','" + TextBox1.Text + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx");
        }
        }
    }
