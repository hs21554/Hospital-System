﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication3
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        private List<string> chatMessages;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                chatMessages = new List<string>();
                Session["ChatMessages"] = chatMessages;
            }
            else
            {
                chatMessages = (List<string>)Session["ChatMessages"];
                DisplayChatMessages();
            }
        }

        protected void sendButton_Click1(object sender, EventArgs e)
        {
            string message = messageTextBox.Text;

            if (!string.IsNullOrEmpty(message))
            {
                chatMessages.Add(message);
                messageTextBox.Text = string.Empty;
                DisplayChatMessages();
                SaveMessageToDatabase(message);
            }
        }
        private void SaveMessageToDatabase(string message)
        {
            string query = "INSERT INTO ChatTable (Username, MessageText, Timestamp) VALUES (@Username, @MessageText, @Timestamp)";
            string constr = @"Data Source=LAPTOP-9AUKFI0Q\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(constr))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", "John"); // Replace with the actual username
                    command.Parameters.AddWithValue("@MessageText", message);
                    command.Parameters.AddWithValue("@Timestamp", DateTime.Now);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        private void DisplayChatMessages()
        {
            chatPanel.Controls.Clear();

            foreach (string message in chatMessages)
            {
                chatPanel.Controls.Add(new LiteralControl("<p>" + message + "</p>"));
            }
        }

       


       
    }
}
