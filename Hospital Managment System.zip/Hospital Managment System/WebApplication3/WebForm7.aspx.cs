﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication3
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
       string constr = @"Data Source=LAPTOP-9AUKFI0Q\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string query = "SELECT PR.name, PR.fname, PR.insurance, AP.docname, AP.shift, PD.bloodreport, PD.treatment FROM PR INNER JOIN AP ON AP.name = PR.name INNER JOIN PD ON PD.name = PR.name";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
              GridView1.EditIndex = e.NewEditIndex;
            this.bind();
        }
        void bind()
        {
            string constr = @"Data Source=LAPTOP-9AUKFI0Q\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
                        string query = "SELECT PR.name, PR.fname, PR.insurance, AP.docname, AP.shift, PD.bloodreport, PD.treatment FROM PR INNER JOIN AP ON AP.name = PR.name INNER JOIN PD ON PD.name = PR.name";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }


        }
    
}  
               

          